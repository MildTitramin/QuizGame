package th.ac.su.quizgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WordDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word_details);
    }
}